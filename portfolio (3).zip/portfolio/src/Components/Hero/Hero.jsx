import React from 'react'
import './Hero.css';
import image from '../../assets/image.png'
import cv from '../../assets/My_cv.pdf'
const Hero = () => {
  return (
    <div id='home' className='hero'>
        <img src={image} alt="profile photo"/>
        <h1><span>I'm Pushpa Mungase,</span> fullstack developer.</h1>
        <p>I'm fullstack developer from india.</p>
        <div className='hero-action'>
          <div className="hero-connect">Connect with me</div>
          <div className="hero-resume"><a href={cv}>My resume</a></div>
        </div>
    </div>
  )
}

export default Hero