import React, { useState } from 'react';
import './About.css';
import theme_pattern from '../../assets/theme_pattern.svg';
import school from '../../assets/school.jpg';
import rahuri from '../../assets/rahuri.jpg';
import rahuri2 from '../../assets/rahuri2.jpg';
import nagarcollege from '../../assets/nagarcollege.jpg';
import image from '../../assets/image.png';

const About = () => {
  // Initializing with the default photo (your personal image)
  const [selectedPhoto, setSelectedPhoto] = useState(image);
  const [selectedInfo, setSelectedInfo] = useState('');

  const handleButtonClick = (level) => {
    if (level === 'ssc') {
      setSelectedInfo(
        <ul>
          <li><span>School:</span> J.K.P.V Vidyalaya</li>
          <li><span>Year:</span> 2016</li>
          <li><span>Marks:</span> 82.40%</li>
        </ul>
      );
      setSelectedPhoto(school);
    } else if (level === 'hsc') {
      setSelectedInfo(
        <ul>
          <li><span>College:</span> Loknete Ramdas Patil Dhumal Arts, Science and Commerce College, Rahuri</li>
          <li><span>Year:</span> 2018</li>
          <li><span>Marks:</span> 69.20%</li>
        </ul>
      );
      setSelectedPhoto(rahuri);
    } else if (level === 'pg') {
      setSelectedInfo(
        <ul>
          <li><span>College:</span> Ahmednagar College</li>
          <li><span>Year:</span> 2023</li>
          <li><span>Marks:</span> 70%</li>
        </ul>
      );
      setSelectedPhoto(nagarcollege);
    } else if (level === 'graduation') {
      setSelectedInfo(
        <ul>
          <li><span>College:</span> Loknete Ramdas Patil Dhumal Arts, Science and Commerce College, Rahuri</li>
          <li><span>Year:</span> 2021</li>
          <li><span>Marks:</span> 85%</li>
        </ul>
      );
      setSelectedPhoto(rahuri2);
    }
  };

  return (
    <>
    <div className='about-title'> 
        <h1 >About Me</h1>
        <img src={theme_pattern} alt="theme_pattern" />
        </div>
   
    <div  id='about' className="about">  
      <div className="about-left">
       
        <p>
          Hi! I'm Pushpa. I completed my PostGraduation from Ahmednagar College in MSc (Physics). 
          I'm currently pursuing PGDAC from CDAC Institute of Training.
        </p>
        <button onClick={() => handleButtonClick('ssc')}>SSC</button>
        <button onClick={() => handleButtonClick('hsc')}>HSC</button>
       
        <button onClick={() => handleButtonClick('graduation')}>Graduation</button>
        <button onClick={() => handleButtonClick('pg')}>PG</button>
        
        {/* Displaying info about the selected education level */}
        <div className="info-display">
          <h3>Details:</h3>
          <div>{selectedInfo}</div>
        </div>
      </div>

      <div className="about-right">
        {/* Displaying the photo */}
        <img src={selectedPhoto} alt="education photo" className="education-photo" />
      </div>
    </div>
    </>
  );
};

export default About;
