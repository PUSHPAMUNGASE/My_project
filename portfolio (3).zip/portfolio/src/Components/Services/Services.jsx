// //rafce
// import React from 'react'
// import './Services.css';
// import theme_pattern from '../../assets/theme_pattern.svg';
// import Services_Data from '../../assets/services_data'
// import arrow_icon from '../../assets/arrow_icon.svg'
// const Services = () => {
//   return (
// <>
//     <div className="services-title">
//     <h1>My Projects</h1>
//     <img src={theme_pattern} alt="theme_pattern" />
//     </div>
//     <div id='services' className='services'>
       
//             <div className="services-container">
//                 {Services_Data.map((service,index)=>{
//                     return (<div key={index} className='services-format'>
//                         <h3>{service.s_no}</h3>
//                         <h2>{service.s_name}</h2>
//                         <p>{service.s_desc}</p>
//                         <div className='services-readmore'>
//                             <p>Read More</p>
//                             <img src={arrow_icon} alt="arrow_icon" />
//                         </div>
//                     </div>)
//                 })}
//             </div>
//             </div>
//             </>
//   )
// }

// export default Services



import React from 'react';
import './Services.css';
import theme_pattern from '../../assets/theme_pattern.svg';
import Services_Data from '../../assets/services_data';
import arrow_icon from '../../assets/arrow_icon.svg';

const Services = () => {

  // Function to handle opening the link when the arrow icon is clicked
  const handleArrowClick = (link) => {
    window.open(link, '_blank'); // Opens the link in a new tab
  };

  return (
    <>
      <div className="services-title">
        <h1>My Projects</h1>
        <img src={theme_pattern} alt="theme_pattern" />
      </div>
      <div id='services' className='services'>
        <div className="services-container">
          {Services_Data.map((service, index) => (
            <div key={index} className='services-format'>
              <h3>{service.s_no}</h3>
              <h2>{service.s_name}</h2>
              <p>{service.s_desc}</p>
              <div 
                className='services-readmore' 
                onClick={() => handleArrowClick(service.s_link)} // Open the specific link
              >
                <p>Read More</p>
                <img src={arrow_icon} alt="arrow_icon" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

export default Services;
