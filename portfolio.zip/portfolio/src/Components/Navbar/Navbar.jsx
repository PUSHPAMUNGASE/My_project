
import React, { useState } from 'react';
import './Navbar.css';
import AnchorLink from 'react-anchor-link-smooth-scroll';
import menu_open from '../../assets/menu_open.svg';
import menu_close from '../../assets/menu_close.svg'

const Navbar = () => {
  const [menu, setMenu] = useState('home');

  return (
    <div className="navbar">
      <h1 className="h1"><b><span className="span">P</span>USHPA</b></h1>
      <img src={menu_open} alt=""  className="nav-mob-open" />
      <ul className="nav-menu">
        <img src={menu_close} alt="" className="nav-mob-close" />
        <li>
          <AnchorLink
            className="anchor-link"
            href="#home"
            offset={50}
            onClick={() => setMenu('home')}
          >
            Home
          </AnchorLink>
        </li>

        <li>
          <AnchorLink
            className="anchor-link"
            href="#about"
            offset={50}
            onClick={() => setMenu('about')}
          >
            About
          </AnchorLink>
        </li>

        <li>
          <AnchorLink
            className="anchor-link"
            href="#services"
            offset={50}
            onClick={() => setMenu('services')}
          >
            Projects
          </AnchorLink>
        </li>

        <li>
          <AnchorLink
            className="anchor-link"
            href="#skills"
            offset={50}
            onClick={() => setMenu('skills')}
          >
            Skills
          </AnchorLink>
        </li>

        <li>
          <AnchorLink
            className="anchor-link"
            href="#contact"
            offset={50}
            onClick={() => setMenu('contact')}
          >
            Contact
          </AnchorLink>
        </li>

        <i className="fas fa-times" onClick={() => closemenu()}></i>
      </ul>
      <i className="fas fa-bars" onClick={() => openmenu()}></i>
    </div>
  );
};

export default Navbar;
