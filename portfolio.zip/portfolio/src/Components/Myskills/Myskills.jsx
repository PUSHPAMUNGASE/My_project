import React from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Pagination } from 'swiper/modules'; // Correct import for Swiper modules
import 'swiper/css'; // Import Swiper styles
import 'swiper/css/pagination'; // Import specific module styles
import './Myskills.css'; // Your custom CSS
import theme_pattern from '../../assets/theme_pattern.svg'
import logo1 from '../../assets/swiper/logo1.jpg';
import logo2 from '../../assets/swiper/logo2.jpg';
import logo3 from '../../assets/swiper/logo3.jpg';
import logo4 from '../../assets/swiper/logo4.jpg';
import logo5 from '../../assets/swiper/logo5.jpg';
import logo6 from '../../assets/swiper/logo6.jpg';
import logo7 from '../../assets/swiper/logo7.jpg';
import logo8 from '../../assets/swiper/logo8.jpg';
import logo9 from '../../assets/swiper/logo9.jpg';
import logo10 from '../../assets/swiper/logo10.jpg';
import logo11 from '../../assets/swiper/logo11.jpg';
import logo12 from '../../assets/swiper/logo12.jpg';

const skills = [
  { id: 1, name: 'React', imgSrc: logo1 },
  { id: 2, name: 'Node.js', imgSrc: logo2 },
  { id: 3, name: 'JavaScript', imgSrc: logo3 },
  { id: 4, name: 'Java', imgSrc: logo4 },
  { id: 5, name: 'Skill 5', imgSrc: logo5 },
  { id: 6, name: 'MongoDB', imgSrc: logo6 },
  { id: 7, name: 'Git', imgSrc: logo7 },
  { id: 8, name: 'css', imgSrc: logo8 },
  { id: 9, name: 'HTML', imgSrc: logo9 },
  { id: 10, name: 'cpp', imgSrc: logo10 },
  { id: 11, name: 'Bootstrap', imgSrc: logo11 },
  { id: 12, name: 'Django', imgSrc: logo12 },
];

const Myskills = () => {
  return (
    <div  id='skills' className='slide-container'>
       <div className="skills-title">
                <h1>My Skills</h1>
                <img src={theme_pattern} alt="" />
            </div>
      <Swiper
      
        slidesPerView={4}
        spaceBetween={30}
        pagination={{
          clickable: true,
        }}
        modules={[Pagination]}
        className="mySwiper"
      >
        {skills.map((skill) => (
          <SwiperSlide key={skill.id}>
            <div className="card">
              <div className="image-content">
                <div className="card-image">
                  <img src={skill.imgSrc} alt={skill.name} className="card-img" />
                </div>
                <div className="card-content">
                  <h4 className="name">{skill.name}</h4>
                </div>
              </div>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
};

export default Myskills;
