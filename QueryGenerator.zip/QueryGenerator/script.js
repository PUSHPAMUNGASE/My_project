document.addEventListener('DOMContentLoaded', () => {
    const quoteText = document.getElementById('quote');
    const authorText = document.getElementById('author');
    const newQuoteBtn = document.getElementById('new-quote');
    const categorySelect = document.getElementById('category');

    // Function to fetch and display a quote
    async function fetchQuote(tag = '') {
        const url = tag ? `https://api.quotable.io/random?tags=${tag}` : 'https://api.quotable.io/random';
        try {
            const response = await fetch(url);
            const data = await response.json();
            quoteText.textContent = `"${data.content}"`;
            authorText.textContent = `- ${data.author}`;
        } catch (error) {
            quoteText.textContent = "Oops, something went wrong. Try again!";
            authorText.textContent = '';
            console.error('Error fetching quote:', error);
        }
    }

    // Event listener for "New Quote" button
    newQuoteBtn.addEventListener('click', () => {
        fetchQuote(categorySelect.value);
    });

    // Event listener for category selection
    categorySelect.addEventListener('change', () => {
        fetchQuote(categorySelect.value);
    });

    // Fetch initial quote
    fetchQuote();
});
