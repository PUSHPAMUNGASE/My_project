 db.patients().insert{"name": "abc",
  "age": 22}

{
   "name": "Pushpa",
  "age": 23,
  "place": "nagar"}