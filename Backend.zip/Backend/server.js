const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(express.json());

app.use(cors());

// Connect to MongoDB
mongoose.connect("mongodb://localhost:27017/hospital", {

});

const patientSchema = new mongoose.Schema({
  name: String,
  age: Number,
});

const Patient = mongoose.model("patients", patientSchema);

// Get all patients
app.get("/patients", async (req, res) => {
  try {
    const patients = await Patient.find();
    res.json(patients);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// Add a new patient
app.post("/patients", async (req, res) => {
  console.log("Request Body:", req.body); // Debug incoming data
  try {
    const patient = new Patient(req.body);
    await patient.save();
    res.json({ message: "Patient added successfully!" });
  } catch (error) {
    res.status(500).send(error.message);
  }
});


// Update a patient
app.put("/patients/:id", async (req, res) => {
  try {
    const updatedPatient = await Patient.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedPatient);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// Delete a patient
app.delete("/patients/:id", async (req, res) => {
  try {
    await Patient.findByIdAndDelete(req.params.id);
    res.json({ message: "Patient deleted successfully!" });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

app.listen(5000, () => {
  console.log("Server is running on port 5000");
});
